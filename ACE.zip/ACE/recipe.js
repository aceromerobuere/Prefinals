const API_URL = 'https://api.spoonacular.com/recipes/random';
const API_KEY = 'a232af90e9924ee78c5b82acad4d40b4'; // API key

document.getElementById('breakfastBtn').addEventListener('click', () => {
  getRandomRecipe('breakfast');
});
document.getElementById('lunchBtn').addEventListener('click', () => {
  getRandomRecipe('lunch');
});
document.getElementById('dinnerBtn').addEventListener('click', () => {
  getRandomRecipe('dinner');
});
document.getElementById('sideDishBtn').addEventListener('click', () => {
  getRandomRecipe('side dish');
});
document.getElementById('dessertBtn').addEventListener('click', () => {
  getRandomRecipe('dessert');
});
document.getElementById('snackBtn').addEventListener('click', () => {
  getRandomRecipe('snack');
});

document.getElementById('surpriseBtn').addEventListener('click', () => {
  getRandomRecipe();
});

// Fetch a random recipe
async function getRandomRecipe(category = '') {
  const recipeDetails = document.getElementById('recipeDetails');
  const spinner = document.getElementById('loadingSpinner');

  // Show spinner and hide recipe details
  spinner.classList.remove('hidden');
  recipeDetails.innerHTML = '';

  try {
    const url = `${API_URL}?apiKey=${API_KEY}${category ? `&tags=${category}` : ''}`;
    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`API request failed with status ${response.status}`);
    }

    const data = await response.json();

    if (data.recipes && data.recipes.length > 0) {
      displayRecipe(data.recipes[0]);
    } else {
      throw new Error('No recipes found.');
    }
  } catch (error) {
    console.error('Error fetching recipe:', error);
    recipeDetails.innerHTML = `
      <p class="error-message">Sorry, we couldn't fetch the recipe. Please try again later.</p>
    `;
  } finally {
    spinner.classList.add('hidden');
  }
}

// Function to display the recipe details
function displayRecipe(recipe) {
  const recipeDetails = document.getElementById('recipeDetails');
  recipeDetails.innerHTML = `
    <h2 class="recipe-title">${recipe.title}</h2>
    <p class="recipe-category">Category: ${recipe.dishTypes?.join(', ') || 'N/A'}</p>
    <h3 class="ingredients-title">Ingredients:</h3>
    <ul class="ingredients-list">
      ${recipe.extendedIngredients.map(ingredient => `<li>${ingredient.original}</li>`).join('')}
    </ul>
    <h3 class="instructions-title">Instructions:</h3>
    <p class="instructions">${recipe.instructions || 'No instructions available.'}</p>
  `;
}